package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class LOTG_VO implements Serializable {

    public String LOTG_ID;
    public String LOTG_01;
    public int LOTG_02;
    public int LOTG_03;
    public String LOTG_04;
    public int LOTG_05;
    public int LOTG_06;
    public String LOTG_07;
    public double LOTG_08;
    public String LOTG_09;
    public String LOTG_98;
    public String LOTG_99;

    public String LOTG_04_DATE;
    public String LOTG_04_CLT;
    public String LOTG_04_UTONG;

    public boolean CHKECK_YN;
    public String DAH_02;
    public String DAH_04;

    public double NGGK_03;
    public double NGGK_04;
    public String NGG_03;
    public String NGG_02;

    public int AvailableCount;


    public boolean Validation;
    public String SUCCESS;
    public String ERROR_MSG;



}
