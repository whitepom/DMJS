package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class MEM_VO implements Serializable {


    public String APP_NOW_NUM;

    //Mobile


    public String MEM_CID;
    public String MEM_01;
    public String MEM_02;
    public String MEM_32;
    public String MEM_32_NM;
    public String SUCCESS;
    public boolean Validation;
    public String ERROR_MSG;

}