package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.base.model.BaseModel;
import kr.hmit.dmjs.model.vo.NGGK_VO;



public class NGGK_Model extends BaseModel implements Serializable {
    public ArrayList<NGGK_VO> Data;
}
