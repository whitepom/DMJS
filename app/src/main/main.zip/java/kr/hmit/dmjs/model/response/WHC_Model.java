package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.base.model.BaseModel;
import kr.hmit.dmjs.model.vo.WHC_VO;

public class WHC_Model extends BaseModel implements Serializable {
    public ArrayList<WHC_VO> Data;

}
