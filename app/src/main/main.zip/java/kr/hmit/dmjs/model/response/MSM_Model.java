package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;


import kr.hmit.dmjs.model.vo.MSM_VO;
import kr.hmit.base.model.BaseModel;

public class MSM_Model extends BaseModel implements Serializable {
    public ArrayList<MSM_VO> Data;

}