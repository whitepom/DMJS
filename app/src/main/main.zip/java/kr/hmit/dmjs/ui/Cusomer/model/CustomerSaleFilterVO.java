package kr.hmit.dmjs.ui.Cusomer.model;
import java.io.Serializable;

public class CustomerSaleFilterVO implements Serializable  {

    public String CLT_02;
    public String CLT_06;
    public String CLT_07;

    public String getCLT_02() {
        return CLT_02;
    }

    public void setCLT_02(String CLT_02) {
        this.CLT_02 = CLT_02;
    }

    public String getCLT_06() {
        return CLT_06;
    }

    public void setCLT_06(String CLT_06) {
        this.CLT_06 = CLT_06;
    }

    public String getCLT_07() {
        return CLT_07;
    }

    public void setCLT_07(String CLT_07) {
        this.CLT_07 = CLT_07;
    }
}
