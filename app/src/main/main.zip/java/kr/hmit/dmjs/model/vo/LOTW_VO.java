package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class LOTW_VO implements Serializable {

    public String LOTW_ID;
    public String LOTW_01;
    public String LOTW_02;
    public String LOTW_98;
    public String LOTW_99;


    public boolean Validation;
    public String SUCCESS;
    public String ERROR_MSG;



}
