package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class LED_VO implements Serializable {

    public String LED_ID;
    public String LED_01;
    public String LED_02;
    public String LED_03;
    public String LED_04;
    public String LED_05;
    public String LED_06;
    public String LED_07;
    public String LED_08;
    public String LED_09;
    public String LED_10;
    public String LED_11;
    public String LED_12;
    public String LED_12_NM;
    public String LED_12NM;
    public String LED_13;
    public String LED_1301;
    public String LED_1302;
    public String LED_14;
    public String LED_15;
    public String LED_16;
    public String LED_17;
    public String LED_18;
    public String LED_19;
    public String LED_20;
    public String LED_21;
    public String LED_21_NM;
    public String LED_21NM;
    public String LED_22;
    public String LED_23;
    public String LED_24;
    public String LED_25;
    public String LED_26;
    public String LED_27;
    public String LED_28;
    public String LED_29;
    public String LED_30;
    public String LED_31;
    public String LED_32;
    public String LED_33;
    public String LED_34;
    public String LED_35;
    public String LED_50;
    public String LED_51;
    public String LED_52;
    public String LED_53;
    public String LED_54;
    public String LED_55;
    public String LED_56;

    public String LED_80;
    public String LED_95;
    public String LED_96;
    public String LED_97;
    public String LED_98;
    public String LED_99;
    public String APP_NOW_NUM;

    //Mobile


    public String SUCCESS;
    public boolean Validation;
    public String ERROR_MSG;

}