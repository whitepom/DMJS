package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class NGM_VO implements Serializable{

    //회사코드
    public String NGM_ID;
    public String NGM_01;
    public String NGM_02;
    public String NGM_03;
    public String NGM_04;

    public String NGM_04_NM;
    public String NGM_05;
    public String NGM_97;
    public String NGM_98;

    public String NGM_02_ST;
    public String NGM_02_ED;

    public String CNT;

    public boolean Validation;

    public String  ERROR_MSG;


    public String getNGM_ID() {
        return NGM_ID;
    }

    public void setNGM_ID(String NGM_ID) {
        this.NGM_ID = NGM_ID;
    }

    public String getNGM_01() {
        return NGM_01;
    }

    public void setNGM_01(String NGM_01) {
        this.NGM_01 = NGM_01;
    }

    public String getNGM_02() {
        return NGM_02;
    }

    public void setNGM_02(String NGM_02) {
        this.NGM_02 = NGM_02;
    }

    public String getNGM_03() {
        return NGM_03;
    }

    public void setNGM_03(String NGM_03) {
        this.NGM_03 = NGM_03;
    }

    public String getNGM_04() {
        return NGM_04;
    }

    public void setNGM_04(String NGM_04) {
        this.NGM_04 = NGM_04;
    }

    public String getNGM_05() {
        return NGM_05;
    }

    public void setNGM_05(String NGM_05) {
        this.NGM_05 = NGM_05;
    }

    public String getNGM_97() {
        return NGM_97;
    }

    public void setNGM_97(String NGM_97) {
        this.NGM_97 = NGM_97;
    }

    public String getNGM_98() {
        return NGM_98;
    }

    public void setNGM_98(String NGM_98) {
        this.NGM_98 = NGM_98;
    }

    public String getNGM_02_ST() {
        return NGM_02_ST;
    }

    public void setNGM_02_ST(String NGM_02_ST) {
        this.NGM_02_ST = NGM_02_ST;
    }

    public String getNGM_02_ED() {
        return NGM_02_ED;
    }

    public void setNGM_02_ED(String NGM_02_ED) {
        this.NGM_02_ED = NGM_02_ED;
    }

    public String getNGM_04_NM() {
        return NGM_04_NM;
    }

    public void setNGM_04_NM(String NGM_04_NM) {
        this.NGM_04_NM = NGM_04_NM;
    }
}
