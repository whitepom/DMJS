package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class BAS_VO implements Serializable {

    public String BAS_ID;
    public String BAS_01;
    public String BAS_02;
    public String BAS_03;
    public String BAS_04;
    public String BAS_05;
    public String BAS_06;
    public String BAS_07;
    public String BAS_0701;
    public String BAS_0702;
    public String BAS_08;
    public String BAS_97;
    public String BAS_98;
    public String BAS_99;

    public String MEM_02;
    public String CLT_02;

    public boolean Validation;
    public String ERROR_MSG;

}
