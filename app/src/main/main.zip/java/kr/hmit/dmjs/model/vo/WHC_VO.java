package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class WHC_VO implements Serializable {

    public String WHC_ID;

    public String WHC_01; // 창고위치1
    public String WHC_02; //창고위치2
    public String WHC_03; //창고위치명
    public boolean Validation;
    public String SUCCESS;
    public String ERROR_MSG;

}
