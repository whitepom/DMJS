package kr.hmit.dmjs.ui.sample;

import java.io.Serializable;

public class AddressModel implements Serializable {
    private static final long serialVersionUID = 1582488442889932224L;

    public String Address;
    public String Zipcode;
}
