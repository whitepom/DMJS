package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class UNO_VO implements Serializable {

    public String UNO_CID;
    public int UNO_01;
    public String UNO_02;
    public String UNO_03;
    public String UNO_04;
    public String UNO_05;
    public String UNO_06;
    public String UNO_11;
    public String UNO_98;
    public String UNO_99;

    public String TMP_01;

    public String MEM_02;
    public String MEM_31;
    public String MEM_32;

    public boolean Validation;
    public String SUCCESS;
    public String ErrorCode;
}
