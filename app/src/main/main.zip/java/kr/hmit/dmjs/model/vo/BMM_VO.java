package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class BMM_VO  implements Serializable {

    public String BMM_ID;
    public String BMM_01;
    public String BMM_02;
    public String BMM_03;
    public String BMM_04;
    public String BMM_05;
    public String BMM_06;
    public String BMM_07;
    public String BMM_08;
    public String BMM_09;
    public String BMM_10;
    public String BMM_11;
    public String BMM_12;
    public String BMM_13;
    public String BMM_14;
    public String BMM_15;
    public String BMM_7001;
    public int BMM_7002;
    public String BMM_98;
    public String BMM_99;
    public String MEM_02;
    public int CNT;
    public String BMM_02_NM;
    public String BAS_99;
    public String BMMF_7001;

    public boolean Validation;
    public String ERROR_MSG;

}
