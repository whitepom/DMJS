package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class NGG_VO implements Serializable{

    //회사코드
    public String NGG_ID;
    public String NGG_01;
    public String NGG_02;
    public String NGG_03;
    public String NGG_03_NM;
    public String NGG_04_NM;
    public String NGG_04;
    public String NGG_05;
    public String NGG_06;
    public String NGG_07;
    public String NGG_08;
    public String NGG_0901;
    public String NGG_0902;
    public String NGG_10;
    public String NGG_11;
    public String NGG_12;
    public String NGG_13;
    public String NGG_14;
    public String NGG_15;
    public String NGG_97;
    public String NGG_98;
    public String NGGK_04;
    public String DAH_01;
    public String DAH_02;
    public String DAH_04;
    public String DAH_14;
    public String DAH_11;
    public String CLT_01;
    public String CLT_02;

    public String LOTG_07;
    public String NGGK_03;
    public String NGGK_06;


    public String CNT;

    public boolean Validation;

    public String  ERROR_MSG;


}
