package kr.hmit.dmjs.ui.m005.filter;

import java.io.Serializable;

public class GagFilterVO implements Serializable {


    public String GAG_04_ST;
    public String GAG_04_ED;

    public String ZAG_03;

    public String GAG_10;

    public String getGAG_04_ST() {
        return GAG_04_ST;
    }

    public void setGAG_04_ST(String GAG_04_ST) {
        this.GAG_04_ST = GAG_04_ST;
    }

    public String getGAG_04_ED() {
        return GAG_04_ED;
    }

    public void setGAG_04_ED(String GAG_04_ED) {
        this.GAG_04_ED = GAG_04_ED;
    }

    public String getZAG_03() {
        return ZAG_03;
    }

    public void setZAG_03(String ZAG_03) {
        this.ZAG_03 = ZAG_03;
    }

    public String getGAG_10() {
        return GAG_10;
    }

    public void setGAG_10(String GAG_10) {
        this.GAG_10 = GAG_10;
    }

    public GagFilterVO() {
    }

}
