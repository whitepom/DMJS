package kr.hmit.dmjs.ui.popup.run.model;

import java.io.Serializable;

public class RunFilterVO implements Serializable {

    public String RUN_01;
    public String RUN_02_ST;
    public String RUN_02_ED;
    public String RUN_2101;

    public String RUN_03;

    public String getRUN_01() {
        return RUN_01;
    }

    public void setRUN_01(String RUN_01) {
        this.RUN_01 = RUN_01;
    }

    public String getRUN_02_ST() {
        return RUN_02_ST;
    }

    public void setRUN_02_ST(String RUN_02_ST) {
        this.RUN_02_ST = RUN_02_ST;
    }

    public String getRUN_02_ED() {
        return RUN_02_ED;
    }

    public void setRUN_02_ED(String RUN_02_ED) {
        this.RUN_02_ED = RUN_02_ED;
    }

    public String getRUN_2101() {
        return RUN_2101;
    }

    public void setRUN_2101(String RUN_2101) {
        this.RUN_2101 = RUN_2101;
    }

    public String getRUN_03() {
        return RUN_03;
    }

    public void setRUN_03(String RUN_03) {
        this.RUN_03 = RUN_03;
    }

    public RunFilterVO() {
    }
}
