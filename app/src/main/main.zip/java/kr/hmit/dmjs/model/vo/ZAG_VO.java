
package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class ZAG_VO implements Serializable {

    public String GUBUN     ;
    public String ZAG_ID    ;
    public String ZAG_01    ;
    public String ZAG_02    ;
    public String ZAG_02_ST ;
    public String ZAG_02_ED ;
    public String ZAG_03    ;
    public String ZAG_03_NM ;
    public double ZAG_04    ;
    public double ZAG_05    ;
    public double ZAG_05_RATE;
    public String ZAG_0405  ;
    public double ZAG_06    ;
    public double ZAG_07    ;
    public String ZAG_08    ;
    public String ZAG_09    ;
    public String ZAG_10    ;
    public String ZAG_10_NM ;

    public double ZAG_11    ;
    public String ZAG_12    ;
    public String ZAG_13    ;
    public String ZAG_1213  ;

    public String ZAG_97    ;
    public String ZAG_98    ;
    public String DAH_02    ;
    public String DAH_14    ;

    public int LOTW_CNT;

    public boolean Validation;
    public String ERROR_MSG;

}
