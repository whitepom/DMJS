package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.dmjs.model.vo.OOK_VO;
import kr.hmit.base.model.BaseModel;

public class OOK_Model extends BaseModel implements Serializable {
    public ArrayList<OOK_VO> Data;

}
