package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class OOK_VO implements Serializable {


    public String OOK_ID;
    public String OOK_01;
    public String OOK_02;
    public String OOK_02_ST;
    public String OOK_02_ED;
    public String OOK_03;
    public String OOK_04_NM;
    public String OOK_04;
    public String OOK_05;
    public String OOK_06;
    public String OOK_07;
    public String OOK_0801;
    public int OOK_0802;
    public String OOK_09;
    public String OOK_10;
    public int OOK_18;
    public double OOK_19;
    public String OOK_20;
    public String OOK_97;
    public String OOK_98;
    public String OOK_99;
    public String DAH_02;
    public String DAH_14;
    public String CDO_03;
    public String dahModels;
    public String MEM_02;
    public String DAH_06;
    public String DAH_04;
    public Double OOK_MONEY;
    public String DAH_11;
    public String OOK_STC;
    public String DAH_01;
    public String OOS_01;
    public String DAH_07;
    public String OOK_AMT;

    public boolean Validation;
    public String SUCCESS;
    public String ERROR_MSG;

}
