package kr.hmit.dmjs.ui.m017.filter;

import java.io.Serializable;

public class ZagFilterVO implements Serializable {


    public String ZAG_02_ST;
    public String ZAG_02_ED;

    public String ZAG_10;

    public String getZAG_02_ST() {
        return ZAG_02_ST;
    }

    public void setZAG_02_ST(String ZAG_02_ST) {
        this.ZAG_02_ST = ZAG_02_ST;
    }

    public String getZAG_02_ED() {
        return ZAG_02_ED;
    }

    public void setZAG_02_ED(String ZAG_02_ED) {
        this.ZAG_02_ED = ZAG_02_ED;
    }

    public String getZAG_10() {
        return ZAG_10;
    }

    public void setZAG_10(String ZAG_10) {
        this.ZAG_10 = ZAG_10;
    }

    public ZagFilterVO() {
    }

}
