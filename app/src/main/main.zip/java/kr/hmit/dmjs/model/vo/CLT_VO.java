package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class CLT_VO implements Serializable {

    public String CLT_ID;
    public String CLT_01;
    public String CLT_02;
    public String CLT_03;
    public String CLT_04;
    public String CLT_GUB;
    public String CLT_05;
    public String CLT_06;
    public String CLT_07;
    public String CLT_08;
    public String CLT_09;
    public String CLT_1001;
    public String CLT_1002;
    public String CLT_1003;
    public String CLT_11;
    public String CLT_12;
    public String CLT_13;
    public String CLT_14;
    public String CLT_15;
    public String CLT_16;
    public String CLT_17;
    public String CLT_18;
    public String CLT_19;
    public String CLT_20;
    public String CLT_21;
    public String CLT_22;
    public String CLT_23;
    public String CLT_24;
    public String CLT_25;
    public String CLT_26;
    public String CLT_27;
    public String CLT_28;
    public String CLT_29;
    public String CLT_29_NM;
    public String CLT_30;
    public String CLT_31;
    public String CLT_32;
    public String CLT_33;
    public String CLT_40;
    public String CLT_50;
    public String CLT_51;
    public String CLT_52;
    public String CLT_53;
    public String CLT_54;
    public String CLT_55;
    public String CLT_97;
    public String CLT_99;
    public String CLT_972;
    public String CLT_9901;
    public String CLT_9902;
    public String CLT_99031;
    public String CLT_9904;
    public String cnt;
    public boolean Validation;
    public String ERROR_MSG;

}
