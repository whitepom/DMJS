package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class FIL_VO implements Serializable {

    public String FIL_ID;
    public String FIL_01;
    public int FIL_02;
    public String FIL_7001;
    public int FIL_7002;
    public String FIL_7003;
    public String FIL_7004;
    public String FIL_98;
    public String FIL_99;

    public String SAVE_FILENAME_LIST;
    public String FILE_DIV;

    public String CMP_17;

    public String CRUD_DIV;

    //Mobile
    public String SUCCESS;

    public boolean Validation;
    public String ERROR_MSG;

}
