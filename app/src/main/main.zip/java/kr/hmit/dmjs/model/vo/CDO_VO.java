package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class CDO_VO implements Serializable {

    public String CDO_ID;
    public String CDO_01;
    public String CDO_02;
    public String CDO_03;
    public String CDO_04;
    public String CDO_05;
    public String CDO_06;
    public String CDO_07;
    public String CDO_80;
    public String CDO_90;
    public String CDO_98;
    public String CDO_99;
    public String MEM_02;
    public String MEM_32;

    public String DELTECHECK_MESSAGE;
    public String CDO_03_NM;


}
