package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class LGC_VO implements Serializable {

    public String LGC_ID;
    public String LGC_01;
    public String LGC_02;
    public String LGC_03;

    public int LGC_80;
    public String LGC_90;
    public String LGC_98;
    public String LGC_99;

    public String MEM_02;
    public String MEM_32;

    public String DELTECHECK_MESSAGE;
    public boolean Validation;

}
