package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class RUN2_VO implements Serializable {

    public String RUN_ID;
    public String RUN_01;
    public String RUN_02;
    public String RUN_03;
    public String RUN_04;
    public String RUN_05;
    public String RUN_06;
    public String RUN_07;
    public String RUN_08;
    public String RUN_09;
    public String RUN_10;
    public String RUN_11;
    public String RUN_12;
    public String RUN_13;
    public String RUN_14;
    public String RUN_1501;
    public String RUN_1502;
    public String RUN_1601;
    public String RUN_1602;
    public String RUN_1603;
    public String RUN_1604;
    public String RUN_1701;
    public String RUN_1702;
    public String RUN_1703;
    public String RUN_18;
    public String RUN_20;
    public String RUN_2101;
    public String RUN_2102;
    public String RUN_2103;
    public String RUN_2201;
    public String RUN_2202;
    public String RUN_2203;
    public String RUN_23;
    public String RUN_24;
    public String RUN_25;
    public String RUN_26;

    public String RUN_27;
    public String RUN_28;

    public String RUN_97;
    public String RUN_98;



    public String TKN_03;
    public String CLT_01;



    public String SUCCESS ;
    public boolean Validation;
    public String ERROR_MSG;

}
