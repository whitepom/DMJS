package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class ODM_VO implements Serializable{

    //회사코드
    public String ODM_ID;

    //발주번호
    public String ODM_01;

    //발주일자
    public String ODM_02;

    //발주처
    public String ODM_03;

    public String ODM_04;

    public String ODM_05;

    public String ODM_06;

    public String ODM_07;

    //비고
    public String ODM_97;

    //최종수정 아이디
    public String ODM_98;

    //최종수정 일시
   public String ODM_99;


    public String ODM_02_ST;
    public String ODM_02_ED;
    public String ODD_02;

    public String ODM_03_NM;

    public String REM_03;

    public float ODM_PCT;
    public String CLT_02;

    public boolean Validation;

    public String  ERROR_MSG;


}
