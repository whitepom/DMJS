package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class BMD_VO implements Serializable {

    public String BMD_ID;
    public String BMD_01;
    public int BMD_02;
    public String BMD_03;
    public String BMD_04;
    public String BMD_05;
    public String BMD_06;
    public int BMD_07;
    public String BMD_08;
    public String BMD_09;
    public String BMD_10;
    public String BMD_11;
    public String BMD_98;
    public String BMD_99;

    public String MEM_02;
    public String BMD_10_NM;
    public String BMD_11_NM;

    public boolean Validation;
    public String ERROR_MSG;

}
