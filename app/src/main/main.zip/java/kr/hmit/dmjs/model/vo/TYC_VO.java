package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class TYC_VO implements Serializable {

    public String TYC_ID;
    public String TYC_01;

    public int TYC_80;
    public String TYC_90;
    public String TYC_98;
    public String TYC_99;

    public String MEM_02;
    public String MEM_32;
    public int TYC_CNT;
    public String DELTECHECK_MESSAGE;

    public boolean Validation;
    public String ERROR_MSG;


}
