package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class REQ_VO implements Serializable {

    public String REQ_ID;
    public String REQ_01;
    public String REQ_02;
    public String REQ_03;
    public String REQ_04;
    public String REQ_05;
    public String REQ_06;
    public String REQ_07;
    public String REQ_08;
    public String REQ_09;
    public String REQ_09_NM;
    public String REQ_10;
    public String REQ_11;
    public String REQ_12;
    public String REQ_6001;
    public String REQ_6002;
    public String REQ_6003;
    public String REQ_6004;
    public String REQ_6005;
    public String REQ_6006;
    public String REQ_97;
    public String REQ_98;
    public String REQ_99;
    public String REQ_03_NM;

    public String D_DAY;
    public String REQ_6004N;
    public String REQ_CK;
    public String MEM_32_NM;
    public String REQ_10_NM;
    public String REQ_11_NM;
    public String REQ_12_NM;
    public String EDAY;
    public String runModels;
    public String DAH_02;
    public String DAH_04;
    public String RUN_06;

    public boolean Validation;
    public String SUCCESS;
    public String ERROR_MSG;

    public String ErrorCode;

}