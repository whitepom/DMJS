package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class LOT_VO implements Serializable {

    public String LOT_ID;
    public String LOT_01;
    public String LOT_02;
    public String LOT_03;
    public String LOT_04;
    public String LOT_0401;
    public String LOT_05;
    public int LOT_06;
    public int LOT_0601;
    public int LOT_07;
    public String LOT_08;
    public String LOT_09;
    public int LOT_10;
    public String LOT_11;
    public String LOT_12;
    public String LOT_13;
    public String LOT_14;
    public String LOT_1501;
    public String LOT_1502;
    public String LOT_1503;
    public String LOT_1601;
    public String LOT_1602;
    public String LOT_17;
    public String LOT_97;
    public String LOT_98;
    public String LOT_99;
    public String LOT_05_NM;
    public String LOT_09_NM;
    public String LOT_11_NM;
    public String LOT_03_NM;
    public String LOT_04_NM;
    public String LOT_04_KG;
    public String SUYUL;
    public String LOTW_CNT;
    public String LOTG_CNT;
    public String LOTB_CNT;
    public String LOTG_SUM;
    public String LOT_98_NM;

    public String LOT_18;
    public String LOT_18_NM;
    public String DAH_14;


    public String LQR_09;


    public boolean Validation;
    public String SUCCESS;
    public String ERROR_MSG;



}
