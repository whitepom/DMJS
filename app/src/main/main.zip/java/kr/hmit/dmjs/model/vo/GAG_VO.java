package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class GAG_VO implements Serializable {

    public String GAG_ID;
    public String GAG_01;
    public String GAG_01_NM;
    public int GAG_02;
    public String GAG_03;
    public String GAG_03_NM;
    public String GAG_04;
    public String GAG_10;

    public int GAG_11;
    public int GAG_13;
    public int GAG_14;
    public String GAG_51;
    public String GAG_52;
    public int GAG_53;

    public String ZAG_03;
    public int ZAG_06;
    public int ZAG_04;
    public double GAG_11_RATE;

    public String GAG_5152;

    public String ZAG_03_NM;

    public String DAH_14;
    public String GAG_10_NM;

    public String MEM_02;

    public int LOT_0601;

    public String LOT_11;

    public int LOT_06;


    public boolean Validation;
    public String ERROR_MSG;

}
