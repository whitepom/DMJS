package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.base.model.BaseModel;
import kr.hmit.dmjs.model.vo.GCM_VO;
import kr.hmit.dmjs.model.vo.LGC_VO;

public class GCM_Model extends BaseModel implements Serializable {
    public ArrayList<GCM_VO> Data;
}
