package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.dmjs.model.vo.CDO_VO;
import kr.hmit.base.model.BaseModel;

public class CDO_Model extends BaseModel implements Serializable {
    public ArrayList<CDO_VO> Data;

}
