package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class NGGK_VO implements Serializable{

    //회사코드
    public String NGGK_ID;
    public String NGGK_01;
    public String NGGK_02;
    public String NGGK_03;

    public double NGGK_04;
    public String NGGK_05;
    public String NGGK_06;
    public String NGGK_07;
    public String NGGK_08;
    public String NGGK_09;

    public String NGGK_10;
    public String NGGK_11;
    public String DAH_01;
    public String DAH_02;
    public String DAH_04;
    public String DAH_14;
    public String DAH_11;
    public String CLT_01;
    public String CLT_02;
    public String cnt;

    public String NGG_02;
    public String NGG_03;
    public String NGG_03_NM;
    public String NGG_04_NM;

    public boolean Validation;

    public String  ERROR_MSG;


}
