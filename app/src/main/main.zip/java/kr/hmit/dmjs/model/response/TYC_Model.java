package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.dmjs.model.vo.TYC_VO;
import kr.hmit.base.model.BaseModel;

public class TYC_Model extends BaseModel implements Serializable {
    public ArrayList<TYC_VO> Data;

}
