package kr.hmit.dmjs.model.vo;

import java.io.Serializable;

public class CODE_VO implements Serializable {

    public String CODE_ID;
    public String CD_NM;
    public String CD;


    public boolean Validation;
    public String SUCCESS;
    public String ERROR_MSG;



}
