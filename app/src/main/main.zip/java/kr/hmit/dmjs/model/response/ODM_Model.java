package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.dmjs.model.vo.ODM_VO;
import kr.hmit.base.model.BaseModel;

public class ODM_Model extends BaseModel implements Serializable {
    public ArrayList<ODM_VO> Data;

}
