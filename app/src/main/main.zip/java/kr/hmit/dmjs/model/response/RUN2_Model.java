package kr.hmit.dmjs.model.response;

import java.io.Serializable;
import java.util.ArrayList;

import kr.hmit.base.model.BaseModel;

import kr.hmit.dmjs.ui.Cusomer.model.MultiItemVO;


public class RUN2_Model extends BaseModel implements Serializable {
    public ArrayList<MultiItemVO> Data;
}
